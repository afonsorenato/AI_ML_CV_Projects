Author: Renato Afonso, 2021

This project consists on having a video file with, for instance, an human or any other object on the COCO dataset.
The output is the same video, but the detected objects (that are part of COCO) are occluded.

There option of running video or a direct stream from camera. The out video is saved as an .mp4 file.

Application: Privacy of the user

